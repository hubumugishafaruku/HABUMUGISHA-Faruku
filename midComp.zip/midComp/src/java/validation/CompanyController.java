/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation;

import dao.GeneralDao;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import model.Company;

/**
 *
 * @author user
 */
public class CompanyController {
    Company c= new Company();
    private String regno;
    private String cname;
    private String category;
    private String owner;
    private String sdate;
    private String registrationDate;
    private String capital;
    private String msg="";

    public CompanyController() {
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    public void getValues(HttpServletRequest request){
        regno=request.getParameter("r");
        cname=request.getParameter("n");
        category=request.getParameter("c");
        owner=request.getParameter("o");
        sdate=request.getParameter("sd");
        //registrationDate=request.getParameter("")
        capital=request.getParameter("p");
}
    public boolean checkRegno (){
        boolean error=false;
        if(regno.length()!=4){
            error=true;
            msg="Value must be 4 digits";
        }
        return error;
    }
    public String getTodaysDate(){
        Date today = new Date();
        
        long currentTime= System.currentTimeMillis();
        today.setTime(currentTime);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
       String c= sdf.format(today);
        return c;
    }
    public void setModel(){
        registrationDate=getTodaysDate();
        c.setRegno(regno);
        c.setCname(cname);
        c.setCategory(category);
        c.setOwner(owner);
        c.setSdate(sdate);
        c.setRegistrationDate(registrationDate);
        c.setCapital(capital);
    }
    public void save() {
        GeneralDao dao= new GeneralDao(Company.class);
        dao.create(c);
    }
    public int coutYear(String date){
    
        Calendar now = Calendar.getInstance();
        
        long tim =System.currentTimeMillis();
        now.setTimeInMillis(tim);
        Date dt = java.sql.Date.valueOf(date);
        
        Calendar time = Calendar.getInstance();
        time.setTime(dt);
        
        int y=now.get(Calendar.YEAR)- time.get(Calendar.YEAR);
        
        
       return y; 
    }
}