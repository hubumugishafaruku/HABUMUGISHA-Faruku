/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rw.voting.model;

/**
 *
 * @author user
 */
public class Validation {
    private String idmsg="";
     private String agemsg="";
      private String namemsg="";

      
      
    public boolean validAge(int a){
     boolean error =false;
     
     if(a<18){
      error=true;
      agemsg="Age must be greate or Equal to 18";
     }
     return error;
    }   
    
    public boolean validateName(String name1,String name2){
        
     boolean error=false;
     
     if(name1.length()<3 | name2.length()<3){
          error=true;
          namemsg="The name must be atleast 3 characters";
     }
     return error;
    }
    
    public boolean validateNationalId(String id,String date){
        
     boolean error=false;
     
        String  nidage =id.substring(1,5);
        String  nidString =date.substring(0,4);       
        
     
     if(id.length()<16){
          error=true;
          idmsg="The national Id must have 16 numbers"; 
          
     }
     if(!(nidage.equals(nidString))){
         error = true;
           
             idmsg="1 up to 5 digit must be equal to dob year";
     }
        System.out.println(nidString +"  " + nidage);
     return error;
    }
      
      
    
    public String getIdmsg() {
        return idmsg;
    }

    public void setIdmsg(String idmsg) {
        this.idmsg = idmsg;
    }

    public String getAgemsg() {
        return agemsg;
    }

    public void setAgemsg(String agemsg) {
        this.agemsg = agemsg;
    }

    public String getNamemsg() {
        return namemsg;
    }

    public void setNamemsg(String namemsg) {
        this.namemsg = namemsg;
    }
      
      
    
}
