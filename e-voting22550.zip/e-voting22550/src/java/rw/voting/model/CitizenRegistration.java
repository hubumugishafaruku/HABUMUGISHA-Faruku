/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rw.voting.model;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import rw.voting.Dao.GeneralDao;
import rw.voting.domain.Citizen;
import rw.voting.domain.District;

/**
 *
 * @author user
 */
public class CitizenRegistration {
    
    public Date changeToDate(String date){
    Date d = java.sql.Date.valueOf(date);
    return d;
    }
//    Validation to check Age > 18
    
    public int getAge(Date d){
     
        Calendar now = Calendar.getInstance();
        
        long tim =System.currentTimeMillis();
        now.setTimeInMillis(tim);
        
        Calendar time = Calendar.getInstance();
        time.setTime(d);
        
        int y=now.get(Calendar.YEAR)- time.get(Calendar.YEAR);
        
        
       return y; 

    }
   
    GeneralDao dao= new GeneralDao(Citizen.class);
    
    public void create(Citizen c){
//        GeneralDao dao= new GeneralDao(Citizen.class);
        dao.create(c);
    }
    
    public List<Citizen> view(){
    List<Citizen> lc =dao.listAll();
    return lc;
    }
    
    
}
